# surrenderAt20Bot
Discord bot that alerts new updates from the Surrender@20 RSS feed